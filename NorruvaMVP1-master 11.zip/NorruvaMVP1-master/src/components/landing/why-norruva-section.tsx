// src/components/landing/why-norruva-section.tsx
// This file's content has been removed as the component is no longer in use.
// It has been replaced by new, more focused landing page sections.
"use client";

export default function WhyNorruvaSection() {
  // Component is deprecated and no longer used. Returning null.
  return null;
}
