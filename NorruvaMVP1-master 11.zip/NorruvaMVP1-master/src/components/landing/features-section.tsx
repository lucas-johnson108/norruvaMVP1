// src/components/landing/features-section.tsx
// This component is no longer in use as its content has been superseded by new, more specific sections.
"use client";

export default function FeaturesSection() {
  // Component is deprecated and no longer used. Returning null.
  return null;
}
