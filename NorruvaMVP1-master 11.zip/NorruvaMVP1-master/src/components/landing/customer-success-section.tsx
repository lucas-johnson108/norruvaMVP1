// src/components/landing/customer-success-section.tsx
// This file's content has been removed as the component is no longer in use.
// It has been replaced by new, more focused landing page sections (e.g. SocialProofSection).
"use client";

export default function CustomerSuccessSection() {
  // Component is deprecated and no longer used. Returning null.
  return null;
}
