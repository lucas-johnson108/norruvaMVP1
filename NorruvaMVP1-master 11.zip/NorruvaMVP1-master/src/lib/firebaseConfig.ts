// src/lib/firebaseConfig.ts
// This file contains your Firebase project configuration.
// IMPORTANT: Replace the placeholder values below with your actual Firebase project credentials.

export const firebaseConfig = {
  apiKey: "AIzaSyYOUR_API_KEY_PLACEHOLDER_SRC",
  authDomain: "your-project-id-src.firebaseapp.com",
  projectId: "your-project-id-src",
  storageBucket: "your-project-id-src.appspot.com",
  messagingSenderId: "123456789012", // Replace with your actual Messaging Sender ID
  appId: "1:123456789012:web:123456abcdef7890fedcba", // Replace with your actual App ID
  measurementId: "G-ABCDEFGHIJ" // Optional: Replace with your actual Measurement ID
};
